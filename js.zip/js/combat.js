"use strict";
const R = {
  corpses: [],
  lootWait: 0,
  ground: [],
  pickTarget: null,
  enemies: [],
  P: null,
  life: 1,
  mana: 1,
  atkT: 0,
  deadT: 0,
  spawnT: 0,
  kills: 0,
  t0: Date.now(),
  logs: [],
  fx: [],
  txt: [],
  dirty: true,
  stall: 0,
  farm: 0,
};
const AR = { w: 400, h: 520, top: 70, bot: 470 };
const H = { x: 768, y: 768, face: 1 };
const zoneIdx = (st) =>
  Math.min(ZONES.length - 1, Math.floor((st - 1) / ZONE_STAGES));
const zoneOf = (st) => ZONES[zoneIdx(st)];
const inZone = (st) => ((st - 1) % ZONE_STAGES) + 1;
function stageLevel(st) {
  if (st > STAGES)
    return Math.min(MAX_LEVEL, 160 + Math.floor((st - STAGES) / 2));
  const z = zoneOf(st);
  return Math.round(
    z.lo + ((inZone(st) - 1) * (z.hi - z.lo)) / (ZONE_STAGES - 1),
  );
}
const isBossStage = (st) => inZone(st) === ZONE_STAGES;
const POISON_TIME = 3;
const CLS = {
  normal: { hp: 1, dmg: 1, xp: 1, r: 17 },
  elite: { hp: 2.5, dmg: 1.3, xp: 3, r: 21 },
  boss: { hp: 9, dmg: 1.7, xp: 20, r: 30 },
};
const DIFFS = [
  {
    n: "Dễ",
    hp: 0.75,
    dmg: 0.7,
    rew: 0.8,
    d: "Quái yếu hơn (máu −25%, sát thương −30%), thưởng −20%",
  },
  { n: "Thường", hp: 1, dmg: 1, rew: 1, d: "Cân bằng chuẩn" },
  {
    n: "Khó",
    hp: 3,
    dmg: 1.6,
    rew: 1.5,
    pot: 0.7,
    d: "Quái máu ×3, sát thương +60%, bình máu chỉ hồi 70%; thưởng +50%; nguồn Hoàng Kim duy nhất khi cày (cấp 80+)",
  },
];
const LATE_DMG_FROM = 120,
  LATE_DMG_SPAN = 60,
  LATE_DMG_MAX = 0;
const lateDmgMul = (D, L) =>
  D && D.n === "Thường"
    ? 1 + LATE_DMG_MAX * clamp((L - LATE_DMG_FROM) / LATE_DMG_SPAN, 0, 1)
    : 1;
const diffOf = () =>
  DIFFS[
    MC().diff != null
      ? MC().diff
      : S && S.chal === "hard"
        ? 2
        : S && [0, 1, 2].includes(S.diff)
          ? S.diff
          : 1
  ];
const HP_TIER = [
  [1, 1],
  [40, 1],
  [60, 1],
  [80, 3],
  [100, 5],
  [120, 7],
  [140, 8],
  [160, 9],
  [180, 10],
];
function hpTier(L) {
  if (window.NO_HP_TIER) return 1;
  if (L <= HP_TIER[0][0]) return HP_TIER[0][1];
  for (let i = 1; i < HP_TIER.length; i++)
    if (L <= HP_TIER[i][0]) {
      const [l0, v0] = HP_TIER[i - 1],
        [l1, v1] = HP_TIER[i],
        k = (L - l0) / (l1 - l0);
      return Math.exp(Math.log(v0) + (Math.log(v1) - Math.log(v0)) * k);
    }
  return HP_TIER[HP_TIER.length - 1][1];
}
function enemyStats(L, cls) {
  const c = CLS[cls];
  return {
    hp: (18 + 8 * L + 0.55 * L * L) * c.hp * (cls === "normal" ? 1 : hpTier(L)),
    dmg: (2 + 1 * L + 0.006 * L * L) * c.dmg,
    ar: 30 + L * 9,
    def: 8 + L * 3.2,
  };
}
const XP_SLOW_FROM = 30,
  XP_SLOW_K = 35,
  XP_SLOW_P = 1.4;
const xpSlow = (L) =>
  L <= XP_SLOW_FROM
    ? 1
    : 1 + XP_SLOW_K * Math.pow((L - XP_SLOW_FROM) / 120, XP_SLOW_P);
function expFor(L) {
  return expNeed(L) / (10 + L * 1.4);
}
function makeEnemy(tid, L, cls, x, y) {
  const m = MON[tid],
    z = zoneOf(S.stage),
    st = enemyStats(L, cls),
    D = diffOf();
  st.hp *= D.hp;
  st.dmg *= D.dmg * lateDmgMul(D, L);
  st.hp *= ADMV.hp;
  st.dmg *= ADMV.dmg;
  const series = wpick([0, 1, 2, 3, 4], (i) => z.sw[i] + 1);
  const res = {};
  ELEM.forEach((e, i) => {
    res[e] = Math.min(m.rmax[i] || 75, L * 0.35 + (cls === "boss" ? 10 : 0));
  });
  const e = {
    id: Math.random(),
    tid: tid,
    n: m.n,
    img: m.img ? img(m.img) : null,
    sz: m.sz,
    L: L,
    cls: cls,
    series: series,
    res: res,
    hp: st.hp,
    max: st.hp,
    dmg: st.dmg,
    ar: st.ar,
    def: st.def,
    x: x,
    y: y,
    r: CLS[cls].r,
    spd: (30 + (m.run || 6) * 4) * (cls === "boss" ? 0.7 : 1),
    atkCd: rnd(0.5, 1.5),
    cd: 1.2 + (18 / Math.max(8, m.spd || 18)) * 0.5,
    ranged: Math.random() < 0.2 && cls !== "boss",
    stun: 0,
    poison: 0,
    poisonDmg: 0,
    hitT: 0,
    face: 1,
  };
  {
    const hm = mutVal("hpMul"),
      dm = mutVal("dmgMul");
    if (hm !== 1 || dm !== 1) {
      e.hp = e.max = e.max * hm;
      e.dmg *= dm;
    }
  }
  if (R.tower || R.tk) applyWeekMod(e);
  return e;
}
function spawnWave() {
  R.enemies = [];
  R.stall = 0;
  const z = zoneOf(S.stage),
    L = stageLevel(S.stage);
  const around = (r0, r1) => {
    const a = rnd(0, Math.PI * 2),
      r = rnd(r0, r1);
    return inWorld(H.x + Math.cos(a) * r, H.y + Math.sin(a) * r);
  };
  const sx = () => (R.sp = around(140, 240))[0],
    sy = () => R.sp[1];
  if (S.wave === WAVES && isBossStage(S.stage)) {
    const bp = around(220, 260);
    R.enemies.push(makeEnemy(z.boss, L + 1, "boss", bp[0], bp[1]));
    R.enemies.push(makeEnemy(pick(z.m), L, "elite", sx(), sy()));
    log(`<b class="boss">${esc(MON[z.boss].n)}</b> xuất hiện!`);
  } else {
    const n = Math.max(
      1,
      Math.round((2 + irnd(0, 2) + (inZone(S.stage) > 5 ? 1 : 0)) * ADMV.spawn),
    );
    for (let i = 0; i < n; i++)
      R.enemies.push(
        makeEnemy(
          pick(z.m),
          L,
          S.wave === WAVES && i === 0 ? "elite" : "normal",
          sx(),
          sy(),
        ),
      );
  }
  if (z.id !== R.zoneShown) {
    R.zoneShown = z.id;
    R.banner = { t: 2.4, text: z.n, sub: `Cấp ${z.lo}–${z.hi}` };
    if (typeof onZoneChange === "function") onZoneChange(z);
  }
}
function hitPercent(ar, def, ignore = 0) {
  const d = (def * (100 - Math.min(ignore, 100))) / 100;
  let p = ar + d === 0 ? 50 : (ar * 100) / (ar + d);
  if (p > MAX_HIT + 4) p = MAX_HIT;
  return Math.max(MIN_HIT, p);
}
function applyPart(
  dmg,
  e,
  attackerSeries,
  targetSeries,
  targetRes,
  targetResMax,
  series5,
) {
  let res = targetRes[e];
  if (counters(attackerSeries, targetSeries)) res -= series5;
  else if (counters(targetSeries, attackerSeries)) res += series5;
  res = clamp(res, -targetResMax, Math.min(targetResMax, MAX_RESIST));
  return (dmg * (100 - res)) / 100;
}
function effRes(e) {
  const ig = R.P && R.P.ignRes;
  if (!ig) return e.res;
  const r = {};
  for (const k in e.res) r[k] = ig[k] ? e.res[k] * (1 - ig[k] / 100) : e.res[k];
  return r;
}
function heroHit(a, e) {
  if (
    a.useAR &&
    Math.random() * 100 >=
      hitPercent(R.P.ar, Math.max(0, e.def - (R.P.curseDef || 0)), a.ignore)
  ) {
    addText(e.x, e.y - e.r - 8, "Trượt", "#aaa", 11);
    return 0;
  }
  const crit = Math.random() * 100 < a.crit;
  let tot = 0,
    best = "phys",
    bv = 0;
  const eres = effRes(e);
  for (const el in a.parts) {
    let d = a.parts[el] * rnd(0.85, 1.15) * ADMV.heroDmg;
    if (el === "poison") {
      const left = e.poison > 0 ? e.poisonDmg * e.poison : 0;
      const pd = applyPart(
        d,
        "poison",
        a.series,
        e.series,
        eres,
        75,
        a.series5,
      );
      R.dmgRaw = (R.dmgRaw || 0) + pd;
      R.dmgUseful = (R.dmgUseful || 0) + pd * POISON_EFF;
      e.poisonDmg = (left + pd) / POISON_TIME;
      e.poison = POISON_TIME;
      continue;
    }
    d = applyPart(d, el, a.series, e.series, eres, 75, a.series5);
    if (crit && el === "phys") d *= CRIT_MULT;
    tot += d;
    if (d > bv) {
      bv = d;
      best = el;
    }
  }
  if (counters(a.series, e.series)) tot += R.P.series5;
  if (e.cls !== "normal" && R.P.bossDmg > 1) tot *= R.P.bossDmg;
  tot = Math.max(1, tot);
  {
    const h0 = Math.max(0, e.hp);
    R.dmgRaw = (R.dmgRaw || 0) + tot;
    R.dmgUseful = (R.dmgUseful || 0) + Math.min(tot, h0);
  }
  e.hp -= tot;
  e.hitT = 0.12;
  if (e.act !== "at") {
    e.act = "hurt";
    e.actT = 0;
    npcSfx(MON[e.tid].anim, "hurt", 0.3);
  }
  if (a.stun && !(e.stunImm > 0) && Math.random() * 100 < a.stun) {
    e.stun = e.cls === "boss" ? 0.5 : 0.8;
    e.stunImm =
      e.cls === "boss" ? STUN_IMM_BOSS : e.cls === "elite" ? STUN_IMM_ELITE : 0;
  }
  if (R.P.leech) heal((tot * R.P.leech) / 100, true);
  if (R.P.manaLeech)
    R.mana = Math.min(R.P.mana, R.mana + (tot * R.P.manaLeech) / 100);
  const k = counters(a.series, e.series) ? " ✦" : "";
  addText(
    e.x,
    e.y - e.r - 6,
    fmt(tot) + k,
    crit ? "#ffe14a" : ELEM_COL[best],
    crit ? 16 : 12,
  );
  return tot;
}
function enemyHit(e) {
  if (ADMV.god) return;
  if (
    Math.random() * 100 >=
    hitPercent(e.ar * (1 - (R.P.curseAR || 0)), R.P.def)
  ) {
    addText(H.x, H.y - 30, "Né", "#9cf", 11);
    return;
  }
  if (R.P.block && Math.random() * 100 < R.P.block) {
    addText(H.x, H.y - 30, "Hóa giải", "#9f9", 11);
    return;
  }
  const el =
    e.series === 1 && Math.random() < 0.4
      ? "poison"
      : e.series === 2 && Math.random() < 0.4
        ? "cold"
        : e.series === 3 && Math.random() < 0.4
          ? "fire"
          : e.series === 4 && Math.random() < 0.3
            ? "light"
            : "phys";
  let d = e.dmg * rnd(0.8, 1.2);
  d = applyPart(d, el, e.series, R.P.series, R.P.res, PLAYER_RES_MAX, 10);
  if (R.P.res5 && !counters(e.series, R.P.series))
    d = Math.max(1, d - R.P.res5);
  const sr = R.P.statusRes && R.P.statusRes[el];
  if (sr) d = Math.max(1, d * (1 - sr / 100));
  if (R.P.absorb) d = Math.max(1, d * (1 - R.P.absorb));
  d = heroGuard(d);
  if (R.P.manaFromHit)
    R.mana = Math.min(R.P.mana, R.mana + (d * R.P.manaFromHit) / 100);
  R.lastHit =
    (e.cls === "boss" ? "trùm " : e.cls === "elite" ? "tinh anh " : "") + e.n;
  R.life -= d;
  R.hurtT = 0.25;
  if (H.act !== "at" && Math.random() < 0.3) {
    H.act = "hurt";
    H.actT = 0;
  }
  if (e.ranged && R.P.retRange) e.hp -= (d * R.P.retRange) / 100;
  if (R.P.retMelee || R.P.retMeleeP) {
    const ret = R.P.retMelee + (d * R.P.retMeleeP) / 100;
    if (ret > 0) {
      e.hp -= ret;
    }
  }
  addText(H.x + rnd(-10, 10), H.y - 36, "-" + fmt(d), "#ff6a5a", 12);
}
function heroGuard(d) {
  const P = R.P;
  if (P.curseDR) d *= 1 - P.curseDR;
  if (P.flatDR) d = Math.max(1, d - P.flatDR);
  if (P.manaShield > 0 && R.mana > 0) {
    const m = Math.min(R.mana, (d * P.manaShield) / 100);
    R.mana -= m;
    d -= m;
  }
  return Math.max(0, d);
}
function heal(v, quiet) {
  const b = R.life;
  R.life = Math.min(R.P.life, R.life + v);
  if (!quiet && R.life - b > 1)
    addText(H.x, H.y - 44, "+" + fmt(R.life - b), "#7f7", 11);
}
const POT_TIER_LV = [0, 1, 20, 40, 70, 100];
function bestPotion(kind) {
  let best = null;
  for (const p of J.potions)
    if (
      p.kind === kind &&
      S.lvl >= (POT_TIER_LV[p.tier] || 999) &&
      potPrice(p) <= S.gold &&
      (!best || p.tier > best.tier)
    )
      best = p;
  return best;
}
const potPrice = (p) => Math.round(p.price * (1 + S.lvl / 25));
function autoPotion(dt) {
  R.hot = R.hot || { life: 0, mana: 0, lifeT: 0, manaT: 0 };
  const h = R.hot,
    P = R.P;
  for (const k of ["life", "mana"]) {
    if (h[k + "T"] > 0) {
      const d = Math.min(dt, h[k + "T"]);
      h[k + "T"] -= dt;
      if (k === "life") R.life = Math.min(P.life, R.life + h.life * d);
      else R.mana = Math.min(P.mana, R.mana + h.mana * d);
    }
  }
  if (S.potOff || S.chal === "nopot") return;
  const needLife = R.life < P.life * 0.5,
    needMana = P.main.cost > 0 && R.mana < P.main.cost * 2;
  h.cd = Math.max(0, (h.cd || 0) - dt);
  for (const [k, need] of [
    ["life", needLife],
    ["mana", needMana],
  ]) {
    const urgent = k === "life" && R.life < P.life * 0.3 && h.cd <= 0;
    if (!need || (h[k + "T"] > 0 && !urgent)) continue;
    if (
      k === "life" &&
      S.siege &&
      typeof siegePotLeft === "function" &&
      siegePotLeft() <= 0
    )
      continue;
    const own = takeStock(k),
      p = own || bestPotion(k);
    if (!p) continue;
    usePotion(k, p, !!own);
    if (k === "life") h.cd = 1;
  }
}
function usePotion(k, p, free) {
  R.hot = R.hot || { life: 0, mana: 0, lifeT: 0, manaT: 0 };
  const h = R.hot;
  if (!free) S.gold -= potPrice(p);
  S.potUsed = (S.potUsed || 0) + 1;
  questTick("pots");
  if (k === "life" && S.siege) S.siege.pots = (S.siege.pots || 0) + 1;
  const left = h[k + "T"] > 0 ? h[k] * h[k + "T"] : 0;
  const eff = k === "life" && !S.siege ? (diffOf().pot ?? 1) : 1;
  h[k + "T"] = p.dur;
  h[k] = (left + p.total * eff) / p.dur;
}
const alive = () => R.enemies.filter((e) => e.hp > 0);
function nearest(list) {
  let b = null,
    bd = 1e9;
  for (const e of list) {
    const d = Math.hypot(e.x - H.x, e.y - H.y);
    if (d < bd) {
      bd = d;
      b = e;
    }
  }
  return b;
}
function rotPool(P) {
  if (S.rot === false || window.NO_ROT) return [];
  const ids = (S.slots || []).filter(Boolean),
    pool = P.actives.filter((a) => ids.includes(a.id));
  if (pool.length < 2) return [];
  const byDps = pool.slice().sort((a, b) => b.dps - a.dps),
    top = byDps[0].dps,
    keep = new Set(byDps.filter((a, i) => i < 2 || a.dps >= top * 0.4));
  return ids
    .map((id) => pool.find((a) => a.id === id))
    .filter((a) => a && keep.has(a));
}
function pickAttack(P, hard) {
  const pool = hard ? [] : rotPool(P);
  if (pool.length < 2) return R.mana >= P.main.cost ? P.main : P.basic;
  const n = pool.length;
  R.rotI = (R.rotI || 0) % n;
  for (let k = 0; k < n; k++) {
    const a = pool[(R.rotI + k) % n];
    if (R.mana >= a.cost) {
      R.rotI = (R.rotI + k + 1) % n;
      return a;
    }
  }
  return P.basic;
}
const heroAttackAction = (a) => {
  if (!a || !a.id) return "at";
  const an =
    typeof JFX !== "undefined" && JFX.f && JFX.f[a.id] && JFX.f[a.id].an;
  return an === 9 || an === 10 ? "at" : an === 14 ? null : "mag";
};
function heroAttack() {
  const P = R.P,
    list = alive();
  if (!list.length) return 0.3;
  const a = pickAttack(
    P,
    list.some((e) => e.cls === "boss" || e.cls === "elite" || e.goldBoss),
  );
  const t = nearest(list);
  const d = Math.hypot(t.x - H.x, t.y - H.y) - t.r;
  if (d > a.rad) {
    R.moveTo = manual() ? null : t;
    return 0.05;
  }
  R.moveTo = null;
  R.mana -= a.cost;
  const c = a.around ? H : t,
    splash = a.around ? a.rad + 40 : 110;
  const targets = list
    .filter(
      (e) =>
        e !== t &&
        Math.hypot(e.x - c.x, e.y - c.y) < (a.targets > 1 ? splash : 0),
    )
    .slice(0, a.targets - 1);
  targets.unshift(t);
  for (const e of targets) {
    heroHit(a, e);
    skillFx(H, e, a);
  }
  H.face = t.x >= H.x ? 1 : -1;
  H.dir = dirOf(t.x - H.x, t.y - H.y);
  {
    const ac = heroAttackAction(a);
    if (ac) {
      H.act = ac;
      H.actT = 0;
      const dl =
        typeof dollOn === "function" && dollOn() ? dollActLen(S, ac) : 0;
      H.actK = dl > 0 ? Math.min(3, Math.max(1, dl / (0.9 / a.rate))) : 1;
    }
  }
  if (a.id) skillSfx(a.id);
  else npcSfx(W.hero[S.fac] && W.hero[S.fac].anim, "at", 0.4);
  return 1 / a.rate;
}
const BOSS_ULT_FROM = 40,
  BOSS_ULT_EVERY = 6;
function bossUlt(e) {
  const P = R.P,
    el =
      ["phys", "poison", "cold", "fire", "light"][e.series] === "phys"
        ? "phys"
        : ["phys", "poison", "cold", "fire", "light"][e.series] || "phys";
  addText(H.x, H.y - 60, "Tuyệt chiêu!", "#ff5a3a", 14);
  if (!R.quiet) R.hurtT = 0.4;
  if (P.block && Math.random() * 100 < P.block) {
    addText(H.x, H.y - 30, "Hóa giải", "#9f9", 11);
    return;
  }
  let d =
    Math.min(0.5, e.goldBoss ? 0.42 : 0.35) *
    P.life *
    rnd(0.9, 1.1) *
    diffOf().dmg;
  d = applyPart(d, el, e.series, P.series, P.res, PLAYER_RES_MAX, 10);
  const sr = P.statusRes && P.statusRes[el];
  if (sr) d *= 1 - sr / 100;
  if (P.absorb) d *= 1 - P.absorb;
  if (P.fatalRes) d *= 1 - P.fatalRes / 100;
  d = heroGuard(d);
  R.lastHit = "Tuyệt chiêu của " + e.n;
  R.life -= Math.max(1, d);
  addText(H.x + rnd(-10, 10), H.y - 36, "-" + fmt(d), "#ff3a2a", 15);
}
const STUN_IMM_ELITE = 1.5,
  STUN_IMM_BOSS = 3;
function enemyAI(e, dt) {
  if (e.stunImm > 0) e.stunImm -= dt;
  if (e.regen && e.hp > 0) e.hp = Math.min(e.max, e.hp + e.max * e.regen * dt);
  if (e.poison > 0) {
    e.poison -= dt;
    e.hp -= e.poisonDmg * dt;
  }
  if (e.stun > 0) {
    e.stun -= dt;
    return;
  }
  const d = Math.hypot(H.x - e.x, H.y - e.y),
    reach = e.ranged ? 200 : e.r + 24;
  e.face = H.x >= e.x ? 1 : -1;
  e.dir = dirOf(H.x - e.x, H.y - e.y);
  e.moving = d > reach;
  if (e.moving) obsChase(e, H.x, H.y, e.spd * dt);
  if (e.cls === "boss" && e.L >= BOSS_ULT_FROM) {
    e.ultCd = (e.ultCd === undefined ? BOSS_ULT_EVERY * 0.4 : e.ultCd) - dt;
    if (e.ultCd <= 0 && d <= reach + 80) {
      e.ultCd = BOSS_ULT_EVERY;
      bossUlt(e);
    }
  }
  e.atkCd -= dt;
  if (d <= reach + 4 && e.atkCd <= 0) {
    e.atkCd = e.cd;
    enemyHit(e);
    e.act = "at";
    e.actT = 0;
    npcSfx(e.animKey || MON[e.tid].anim, "at", 0.35);
    if (e.ranged) fxLine(e, H, { parts: { phys: 1 } });
  }
}
function tick(dt) {
  obsFrame();
  if (typeof OBS !== "undefined" && OBS.g && !obsWalk(H.x, H.y)) {
    const _p = obsSnap(H.x, H.y);
    H.x = _p[0];
    H.y = _p[1];
  }
  if ((R.sweepT = (R.sweepT || 0) + dt) > 30) {
    R.sweepT = 0;
    autoEquipAll();
    sweepJunk();
    autoBuyWeapon();
    autoForge();
    checkHints();
    blessSweep();
  }
  if (R.dirty) recalc();
  const P = R.P;
  if (R.deadT > 0) {
    R.deadT -= dt;
    if (R.deadT <= 0) {
      R.life = P.life;
      R.mana = P.mana;
      S.wave = 1;
      spawnWave();
    }
    return;
  }
  R.life = Math.min(P.life, R.life + P.regen * dt);
  R.mana = Math.min(P.mana, R.mana + P.manaRegen * dt);
  autoPotion(dt);
  if (R.hurtT > 0) R.hurtT -= dt;
  if (R.tpCd > 0) R.tpCd -= dt;
  if (R.potCd) {
    R.potCd.life = Math.max(0, R.potCd.life - dt);
    R.potCd.mana = Math.max(0, R.potCd.mana - dt);
  }
  goldBossTick(dt);
  petTick(dt);
  if (R.town) {
    townTick(dt);
    return;
  }
  R.activeT = (R.activeT || 0) + dt;
  jrAdd("sec", dt);
  const looting = updateGround(dt);
  if (!R.enemies.length) {
    if (manual()) moveManual(dt);
    if (looting && R.lootWait < 8) {
      R.lootWait += dt;
      return;
    }
    if (R.spawnT > 0) {
      R.spawnT -= dt;
      return;
    }
    R.lootWait = 0;
    if (R.tk) tkSpawn();
    else if (S.siege) siegeSpawn();
    else if (R.tower) towerSpawn();
    else {
      spawnWave();
      if (goldBossDue()) spawnGoldBoss();
    }
    return;
  }
  if (manual()) moveManual(dt);
  if (!(looting && R.pickTarget)) {
    if (manual()) {
    } else if (R.moveTo && R.moveTo.hp > 0) {
      obsSteer(H, R.moveTo.x, R.moveTo.y, 150 * P.speed * dt);
    }
    R.atkT -= dt;
    if (R.atkT <= 0) R.atkT = heroAttack();
  }
  if (R.enemies.length) R.tFight = (R.tFight || 0) + dt;
  for (const e of alive()) enemyAI(e, dt);
  killCheck();
  R.stall += dt;
  if (R.stall > 45) stallOut();
  if (R.life <= 0) heroDeath();
}
function stallOut() {
  R.stall = 0;
  if (R.tk) {
    tkExit(false);
    return;
  }
  if (S.siege) {
    siegeExit(false);
    return;
  }
  if (R.tower) {
    towerExit(false);
    return;
  }
  const boss = R.enemies.some((e) => !e.dead && e.cls === "boss");
  if (boss || S.wave === WAVES) {
    if (R.enemies.some((e) => e.goldBoss && !e.dead)) RW().gbT = GB_RETRY;
    log('<span class="dim">Đánh mãi không hạ được, lui về luyện công.</span>');
    if (S.stage > 1) {
      S.stage--;
      S.push = false;
      R.farm = 0;
    }
    S.wave = 1;
    if (typeof onStageChange === "function") onStageChange();
  } else log('<span class="dim">Đợt quái kéo dài quá lâu, gọi đợt mới.</span>');
  spawnWave();
}
function killCheck() {
  for (const e of R.enemies)
    if (e.hp <= 0 && !e.dead) {
      e.dead = true;
      onKill(e);
      npcSfx(MON[e.tid].anim, "die", 0.5);
      if (!R.quiet) {
        e.act = "die";
        e.actT = 0;
        R.corpses.push(e);
      }
    }
  if (R.enemies.length && R.enemies.every((e) => e.dead)) {
    R.enemies = [];
    waveCleared();
  }
}
function onKill(e) {
  dexMark(e.tid);
  R.kills++;
  S.totalKills = (S.totalKills || 0) + 1;
  burst(e.x, e.y, SERIES_COL[e.series]);
  if (R.tk) {
    R.tk.kills++;
    return rwOnKill(e);
  }
  if (S.siege) {
    S.siege.kills = (S.siege.kills || 0) + 1;
    return rwOnKill(e);
  }
  

const pay = !R.tower || towerFirst();
if (pay) {
  if (R.tower) {
    (R.tower.pend = R.tower.pend || []).push({
      L: e.L,
      cls: e.cls,
      x: e.x,
      y: e.y,
      goldBoss: e.goldBoss,
      n: e.n,
    });
  } else {
    payKill(e);
  }
} else if (R.tower) {
  for (const it of rollDrops(e)) {
    dropToGround(it, e);

    if (typeof ytGearMatch === "function" && ytGearMatch(it)) {
      ytTick("gear");
      log(`<b class="up">Dã Tẩu:</b> tìm thấy ${esc(it.n)}`);
    }

    if (it.cp) {
      log(
        `<b style="color:${RAR_COL[1]}">✦ ${esc(it.n)}</b> rơi ra! (đồ Xanh chỉ số gần tối đa)`,
      );
    }
  }

  for (const m of allDrops(e)) {
    log(`Nhặt được <b style="color:${RAR_COL[3]}">${esc(m)}</b>`);
  }

  const gold = rollSetDrop(e);
  if (gold) {
    dropToGround(gold, e);
    log(`<b style="color:${RAR_COL[gold.r]}">${esc(gold.n)}</b> rơi ra!`);
  }
}

rwOnKill(e);
}
function payKill(e) {

  rwOnKill(e);
}
function payKill(e) {
  const lvDiff = e.L - S.lvl,
    mult = lvDiff < -10 ? 0.2 : lvDiff < -5 ? 0.6 : 1;
  const xpL = R.tower ? Math.min(e.L, S.lvl + 5) : e.L;
  R.jrOn = true;
  gainXp(
    expFor(xpL) *
      CLS[e.cls].xp *
      ctcBossXp(e) *
      ctcManualXp() *
      mult *
      diffOf().rew *
      (R.tower ? towerXp() : 1),
  );
  R.jrOn = false;
  const g = Math.round(moneyDrop(e) * diffOf().rew * modeGoldMul());
  S.gold += g;
  jrAdd("gold", g);
  jrAdd("kills", 1);
  for (const it of rollDrops(e)) {
    dropToGround(it, e);
    if (typeof ytGearMatch === "function" && ytGearMatch(it)) {
      ytTick("gear");
      log(`<b class="up">Dã Tẩu:</b> tìm thấy ${esc(it.n)}`);
    }
    if (it.cp)
      log(
        `<b style="color:${RAR_COL[1]}">✦ ${esc(it.n)}</b> rơi ra! (đồ Xanh chỉ số gần tối đa)`,
      );
  }
  for (const m of allDrops(e))
    log(`Nhặt được <b style="color:${RAR_COL[3]}">${esc(m)}</b>`);
  const gold = rollSetDrop(e);
  if (gold) {
    dropToGround(gold, e);
    log(`<b style="color:${RAR_COL[gold.r]}">${esc(gold.n)}</b> rơi ra!`);
  }
  if (e.cls === "boss")
    log(`Hạ <b class="boss">${esc(e.n || "trùm")}</b> (+${fmt(g)} lượng)`);
}
var XP_RAW = false;
function gainXp(x) {
  if (S.lvl >= MAX_LEVEL) return;
  if (!XP_RAW) x *= modeXpMul() * xpBuffMul();
  const f = XP_RAW
    ? 1
    : (1 + rebornBonus().xp + (R.P ? R.P.xpBonus || 0 : 0) / 100) /
      xpSlow(S.lvl);
  if (R.jrOn) jrAdd("xp", x * f);
  S.xp += x * f;
  if (!XP_RAW) R.xpTot = (R.xpTot || 0) + x * f;
  while (S.lvl < MAX_LEVEL && S.xp >= expNeed(S.lvl)) {
    S.xp -= expNeed(S.lvl);
    S.lvl++;
    S.attrPts += PTS_PER_LEVEL;
    S.skPts += SKILL_PTS_PER_LEVEL;
    R.dirty = true;
    uiSfx("levelup");
    log(
      `<b class="up">Lên cấp ${S.lvl}!</b> +${PTS_PER_LEVEL} tiềm năng, +${SKILL_PTS_PER_LEVEL} kỹ năng`,
    );
    if (typeof onLevelUp === "function") onLevelUp();
  }
}
function waveCleared() {
  if (R.tk) {
    tkCleared();
    return;
  }
  if (S.siege) {
    siegeCleared();
    return;
  }
  if (R.tower) {
    towerCleared();
    return;
  }
  heal(R.P.life * 0.15, true);
  R.mana = Math.min(R.P.mana, R.mana + R.P.mana * 0.2);
  if (S.wave < WAVES) {
    S.wave++;
    R.spawnT = 1.2;
    return;
  }
  S.wave = 1;
  if (!S.push && ++R.farm >= 3 && R.life > R.P.life * 0.6) {
    S.push = true;
    R.farm = 0;
    log("Đủ mạnh, thử vượt ải tiếp.");
  }
  if (S.push) {
    if (S.stage < STAGE_CAP && stageLevel(S.stage + 1) <= S.lvl + STAGE_GATE) {
      S.stage++;
      S.maxStage = Math.max(S.maxStage, S.stage);
      questTick("stages");
    }
    if (inZone(S.stage) === 1 && S.stage <= STAGES)
      log(`Tiến vào <b>${esc(zoneOf(S.stage).n)}</b>`);
  }
  if (typeof onStageChange === "function") onStageChange();
}
function heroDeath() {
  jrDeath(R.lastHit || "không rõ");
  if (R.enemies.some((e) => e.goldBoss && !e.dead)) RW().gbT = GB_RETRY;
  R.deadT = 3;
  R.life = 0;
  R.enemies = [];
  log('<span class="bad">Bạn đã trọng thương.</span>');
  if (R.tk) {
    tkExit(true);
    return;
  }
  if (S.siege) {
    siegeExit(true);
    return;
  }
  if (R.tower) {
    towerExit(true);
    return;
  }
  if (S.stage > 1) {
    S.stage--;
    S.push = false;
    R.farm = 0;
    log(`Lùi về ải ${S.stage} để luyện công.`);
  }
  if (typeof onStageChange === "function") onStageChange();
}
function recalc() {
  const fl = R.P ? R.life / R.P.life : 1,
    fm = R.P ? R.mana / R.P.mana : 1;
  R.P = calc();
  R.life = Math.min(R.P.life, R.P.life * fl);
  R.mana = Math.min(R.P.mana, R.P.mana * fm);
  R.power = power(R.P);
  R.dirty = false;
  R.aura = null;
}
function simulate(seconds, step = 0.05) {
  const q = R.quiet;
  R.quiet = true;
  for (let t = 0; t < seconds; t += step) tick(step);
  R.quiet = q;
}
