"use strict";
const J = window.JX,
  W = window.JW;
const $ = (s) => document.querySelector(s);
const rnd = (a, b) => a + Math.random() * (b - a);
const irnd = (a, b) => Math.floor(a + Math.random() * (b - a + 1));
const pick = (a) => a[Math.floor(Math.random() * a.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const fmt = (n) => {
  n = Math.round(n);
  const a = Math.abs(n);
  return a < 1e4
    ? "" + n
    : a < 1e6
      ? (n / 1e3).toFixed(a < 1e5 ? 1 : 0) + "k"
      : a < 1e9
        ? (n / 1e6).toFixed(2) + "M"
        : (n / 1e9).toFixed(2) + "B";
};
const esc = (s) =>
  String(s).replace(
    /[&<>"]/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c],
  );
const noMark = (s) =>
  String(s == null ? "" : s)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d")
    .replace(/Đ/g, "D")
    .toLowerCase();
const kwHit = (name, kw) => {
  const k = noMark(kw).trim();
  return !k || noMark(name).indexOf(k) >= 0;
};
const localISODay = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function wpick(list, w) {
  let t = 0;
  for (const x of list) t += w(x);
  let r = Math.random() * t;
  for (const x of list) {
    r -= w(x);
    if (r <= 0) return x;
  }
  return list[list.length - 1];
}
const SERIES = J.series;
const SERIES_COL = ["#f3d35b", "#6fd46a", "#5fb8ff", "#ff6a3a", "#c8965a"];
const KHAC = { 0: 1, 1: 4, 4: 2, 2: 3, 3: 0 };
const counters = (a, t) => a >= 0 && t >= 0 && KHAC[a] === t;
const ELEM = ["phys", "poison", "cold", "fire", "light"];
const ELEM_VI = {
  phys: "Vật lý",
  poison: "Độc",
  cold: "Băng",
  fire: "Hỏa",
  light: "Lôi",
};
const ELEM_COL = {
  phys: "#f0e6d0",
  poison: "#8fe34a",
  cold: "#7fd0ff",
  fire: "#ff7a2a",
  light: "#d9b6ff",
};
const ELEM_ATTR = {
  phys: "physicsdamage_v",
  poison: "poisondamage_v",
  cold: "colddamage_v",
  fire: "firedamage_v",
  light: "lightingdamage_v",
};
const ELEM_ADD = {
  phys: "addphysicsdamage_v",
  poison: "addpoisondamage_v",
  cold: "addcolddamage_v",
  fire: "addfiredamage_v",
  light: "addlightingdamage_v",
};
const ELEM_RES = {
  phys: "physicsres_p",
  poison: "poisonres_p",
  cold: "coldres_p",
  fire: "fireres_p",
  light: "lightingres_p",
};
const ELEM_ENH = {
  poison: "poisonenhance_p",
  cold: "coldenhance_p",
  fire: "fireenhance_p",
  light: "lightingenhance_p",
};
const BLOCK_MAX = 35,
  ABSORB_MAX = 0.45,
  ABSORB_K = 220,
  SKILL_ENH_MAX = 60;
const MAX_RESIST = 95,
  PLAYER_RES_MAX = 75,
  MAX_HIT = 95,
  MIN_HIT = 40,
  CRIT_MULT = 2;
const STR_PER_DMG = 5,
  DEX_PER_DMG = 5,
  ENG_PER_DMG = 4;
const STATUS_RES_MAX = 50,
  XP_ENH_MAX = 50;
const ENG_PER_PCT = 1,
  STR_PER_PCT = 1,
  DEX_PCT_RANGED = 0.5,
  IDLE_LIFE_PER_LEVEL = 8;
const PTS_PER_LEVEL = 5,
  SKILL_PTS_PER_LEVEL = 1,
  MAX_LEVEL = 1100;
console.log("Số phần tử J.exp:", J.exp.length);
console.log("MAX_LEVEL:", MAX_LEVEL);
const EXP_TAIL_R = J.exp[98] / J.exp[97];
function expNeed(L) {
  const l = Math.max(1, Math.min(Math.floor(L) || 1, MAX_LEVEL));
  return l <= 99 ? J.exp[l - 1] : J.exp[98] * Math.pow(EXP_TAIL_R, l - 99);
}
const ATTR_ID = Object.fromEntries(J.attr.map((n, i) => [n, i]));
function attrText(name, p) {
  const t = J.attrDesc[name];
  if (!t) return name + ": " + p.filter((v) => v).join(" / ");
  return t
    .replace(/<color(=\w+)?>/g, "")
    .replace(/#([a-zA-Z])([123A])([-+~%]?)/g, (m, k, i, flag) => {
      const v = i === "A" ? Math.floor((p[0] || 0) / 256) : p[+i - 1] || 0;
      if (k === "l") return J.skills[v] ? J.skills[v].n : "#" + v;
      return (flag === "+" && v > 0 ? "+" : "") + v;
    })
    .replace(/#[a-zA-Z][123A][-+~]?/g, "")
    .replace(/Kỹ năng (\d+)/, (m, id) =>
      J.skills[id] ? "Kỹ năng " + J.skills[id].n : m,
    );
}
const FACTIONS = J.factions.filter((f) => f.skills && f.skills.length);
const FAC = Object.fromEntries(FACTIONS.map((f) => [f.key, f]));
const SK = J.skills;
for (const f of FACTIONS) {
  const first = f.skills
    .map((id) => SK[id])
    .filter(
      (s) =>
        s &&
        s.enemy &&
        [
          "physicsenhance_p",
          "physicsdamage_v",
          "poisondamage_v",
          "colddamage_v",
          "firedamage_v",
          "lightingdamage_v",
        ].some((a) => s.attr[a]),
    )
    .sort((a, b) => a.req - b.req || a.id - b.id);
  if (first.length) {
    first[0].req = 1;
    f.starter = first[0].id;
  }
  const mastery = f.skills
    .map((id) => SK[id])
    .filter((s) => s && !s.enemy && s.attr.addphysicsdamage_p)
    .sort((a, b) => a.req - b.req || a.id - b.id)[0];
  const a = mastery && mastery.attr.addphysicsdamage_p[0];
  f.wcode =
    Array.isArray(a) && [0, 1, 2, 3, 4, 5, 7, 9].includes(a[2]) ? a[2] : -1;
}
const skVal = (s, attr, L) => {
  const a = s.attr[attr];
  if (!a || !a.length) return null;
  const v = a[clamp(L, 1, a.length) - 1],
    out = Array.isArray(v) ? v : [v, 0, 0];
  if (
    L <= a.length ||
    a.length < 2 ||
    a.length < s.max ||
    /^(missle_|skill_)/.test(attr)
  )
    return out;
  const prev = a[a.length - 2],
    p = Array.isArray(prev) ? prev : [prev, 0, 0];
  const extra = Math.min(SKILL_LV_MAX, L - a.length);
  return out.map((n, i) => {
    const damageRange = /^(physics|cold|fire|lighting)damage_v$/.test(attr);
    if (
      (attr.startsWith("addskilldamage") ? i !== 2 : i > 1 && !damageRange) ||
      !Number.isFinite(n) ||
      !Number.isFinite(p[i])
    )
      return n;
    const value = n + (n - p[i]) * extra;
    return n >= 0 ? Math.max(0, value) : Math.min(0, value);
  });
};
const DMG_ATTRS = [
  "physicsenhance_p",
  "physicsdamage_v",
  "poisondamage_v",
  "colddamage_v",
  "firedamage_v",
  "lightingdamage_v",
];
const dmgSource = (s) => {
  if (!s || !s.enemy || Object.keys(s.attr || {}).length > 0)
    return s && s.enemy && DMG_ATTRS.some((a) => s.attr && s.attr[a])
      ? s
      : null;
  let cur = s,
    n = 0;
  while (cur && n++ < 3) {
    if (cur.enemy && DMG_ATTRS.some((a) => cur.attr && cur.attr[a])) return cur;
    cur = cur.child ? SK[cur.child] : null;
  }
  return null;
};
const isAttack = (s) => !!dmgSource(s);
const isCurse = (s) => !!(s && s.enemy && !isAttack(s));
const DEAD_SKILLS = {
  22: "Kim Ba: attr rong, child tro toi skill noi tai (khong co dong sat thuong trong du lieu goc)",
  186: "Hong Ba: attr rong, child=79 la noi tai tang cong tay khong",
  191: "Quan Am Tan Tuyet: attr rong, child=81/204 deu noi tai",
};
const ZONES = W.zones,
  MON = W.mon;
const ZONE_STAGES = 10,
  WAVES = 4;
const STAGES = ZONES.length * ZONE_STAGES;
const STAGE_CAP = STAGES + 2 * Math.max(0, MAX_LEVEL - 160);
const STAGE_GATE = 5;
const SLOTS = [
  ["weapon", "Vũ khí"],
  ["armor", "Áo"],
  ["helm", "Mũ"],
  ["belt", "Đai lưng"],
  ["boot", "Giày"],
  ["cuff", "Hộ uyển"],
  ["amulet", "Dây chuyền"],
  ["ring1", "Nhẫn 1"],
  ["ring2", "Nhẫn 2"],
  ["pendant", "Ngọc bội"],
  ["horse", "Ngựa"],
];
const SLOT_VI = Object.fromEntries(SLOTS);
const DETAIL_SLOT = [
  "weapon",
  "weapon",
  "armor",
  "ring",
  "amulet",
  "boot",
  "belt",
  "helm",
  "cuff",
  "pendant",
  "horse",
];
const MELEE_KIND = ["sword", "blade", "wand", "spear", "hammer", "dualblades"],
  RANGE_KIND = ["darts", "knife", "crossbow"];
const AFFIX_KEY = {
  armor: "armor",
  ring: "ring",
  amulet: "necklace",
  boot: "boot",
  belt: "belt",
  helm: "helm",
  cuff: "cuff",
  pendant: "pendant",
};
const RAR_VI = ["Thường", "Xanh", "Vàng", "Tím", "Hoàng Kim", "Bạch Kim"],
  RAR_COL = ["#ffffff", "#6464ff", "#ffd24a", "#aa1eff", "#ffff00", "#ffff00"];
const INV_MAX = 60;
const SKILL_LV_MAX = 2,
  LEECH_MAX = 5;
const ENH_MAX = 10,
  ENH_STEP = 0.08;
const PLAT_STEP = 0.05;
const enhMul = (it) =>
  1 + ENH_STEP * ((it && it.enh) || 0) + PLAT_STEP * ((it && it.plv) || 0);
const WORLD = { w: 3072, h: 3072, pad: 20 };
const clampWorld = (x, y) => [
  clamp(x, WORLD.pad, WORLD.w - WORLD.pad),
  clamp(y, WORLD.pad + 30, WORLD.h - WORLD.pad),
];
const inWorld = (x, y) => {
  const p = clampWorld(x, y);
  return typeof OBS !== "undefined" && OBS.g ? obsSnap(p[0], p[1]) : p;
};
const thichGiamChuyenDong = () =>
  !!(
    window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches
  );
const giamHieuUng = () =>
  S && S.lowFx !== undefined && S.lowFx !== null
    ? !!S.lowFx
    : thichGiamChuyenDong();
const canonAttr = (n) => (n.indexOf("_yan") >= 0 ? n.replace("_yan", "") : n);
const attrName = (id) => J.attr[id] || "#" + id;
