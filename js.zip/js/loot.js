"use strict";
const FACTION_WEAPON_SHARE = 0.5;
const BLUE_BOOST_STAGE = 40;
const DROP_OVER = 5;
const dropLv = (e) => Math.min(e.L, S.lvl + DROP_OVER);
function dropFile(L) {
  const b =
    L < 110 ? clamp(Math.floor(L / 10) * 10, 10, 90) : L < 119 ? 110 : 119;
  return J.drop["npcdroprate" + b + ".ini"] || J.drop["npcdroprate.ini"];
}
function itemTier(L, df) {
  const m = df.main;
  return clamp(
    Math.round(L / 12) + irnd(-1, 1),
    m.MinItemLevel || 1,
    m.MaxItemLevel || 10,
  );
}
function baseRow(detail, particular, tier) {
  const g = J.items[detail];
  if (!g) return null;
  let rows = g.list.filter((r) => r.k === particular);
  if (!rows.length) return null;
  const okRows = rows.filter((r) => sexReqOk(r.req));
  if (okRows.length) rows = okRows;
  return rows.reduce((b, r) =>
    Math.abs(r.lvl - tier) < Math.abs(b.lvl - tier) ? r : b,
  );
}
const DEAD_AFFIX = new Set([
  "staminamax_v",
  "staminareplenish_v",
  "stamina_v",
  "visionradius_p",
  "fasthitrecover_v",
  "indestructible_b",
  "knockback_p",
  "addphysicsmagic_v",
  "addcoldmagic_v",
  "addfiremagic_v",
  "addlightingmagic_v",
  "addpoisonmagic_v",
]);
function rollMagic(it, levels, lucky = 0, allPre = false, bias = 0) {
  const out = [],
    used = new Set();
  out.qmin = 1;
  for (let i = 0; i < levels.length; i++) {
    const pre = allPre || i % 2 === 0 ? 1 : 0,
      lv = levels[i];
    const decide = Math.floor(Math.random() * 100) / (1 + (lucky * 20) / 100);
    const cand = J.affix.filter(
      (a) =>
        a.pre === pre &&
        (a.s < 0 || a.s === it.s) &&
        a.lvl <= lv &&
        (a.w[it.d] || 0) > decide &&
        !used.has(a.a) &&
        !DEAD_AFFIX.has(canonAttr(attrName(a.a))),
    );
    if (!cand.length) break;
    const a = pick(cand);
    used.add(a.a);
    const p = a.p.map(([mn, mx]) => {
      if (mn === -1 && mx === -1) return -1;
      const lo = Math.min(mn, mx),
        hi = Math.max(mn, mx);
      return bias && Math.random() < bias
        ? Math.max(irnd(lo, hi), irnd(lo, hi))
        : irnd(lo, hi);
    });
    {
      const r = a.p[0];
      if (r && !(r[0] === -1 && r[1] === -1)) {
        const lo = Math.min(r[0], r[1]),
          hi = Math.max(r[0], r[1]);
        if (hi > lo) out.qmin = Math.min(out.qmin, (p[0] - lo) / (hi - lo));
      }
    }
    out.push({ a: a.a, p: p, n: a.n, pre: pre });
  }
  return out;
}
const YELLOW_P = { normal: 15, elite: 30, boss: 55 };
let DROP_BOSS = false;
const luckyNow = () =>
  ((R.P ? R.P.lucky : 0) + ADMV.lucky) * (DROP_BOSS ? 2 : 1);
const CTC_LUCK_K = 5,
  CTC_LUCK_BASE = 10,
  CTC_CP_Q = 0.95;
const luckyQ = () =>
  modeId() === "ctc"
    ? (luckyNow() + CTC_LUCK_BASE * (DROP_BOSS ? 2 : 1)) * CTC_LUCK_K
    : luckyNow();
function magicCount(cls) {
  const y =
      ((YELLOW_P[cls] ?? YELLOW_P.normal) + luckyNow() * 0.5) *
      (cls === "boss" ? 2 : 1),
    r = Math.random() * 100;
  if (r >= y) return 2;
  return r < y * 0.2 ? irnd(5, 6) : irnd(3, 4);
}
const lineScale = (L) =>
  L >= 120 ? 1 + Math.min(0.18, 0.03 * (Math.floor((L - 120) / 10) + 1)) : 1;
const magicLevels = (n, tier) =>
  Array.from({ length: n }, () => clamp(tier + irnd(0, 1), 1, 10));
function rarityOf(n) {
  return n >= 3 ? 2 : n >= 1 ? 1 : 0;
}
const randomSeries = () => irnd(0, 4);
function sexPart(detail, part) {
  const g = J.items[detail];
  if (!g) return part;
  const rows = g.list.filter((r) => r.k === part);
  if (!rows.length || rows.some((r) => sexReqOk(r.req))) return part;
  const alt = [
    ...new Set(g.list.filter((r) => sexReqOk(r.req)).map((r) => r.k)),
  ];
  return alt.length ? pick(alt) : part;
}
function makeItem(detail, particular, tier, nMagic) {
  const b = baseRow(detail, particular, tier);
  if (!b) return null;
  const it = {
    uid: S.uid++,
    d: detail,
    k: particular,
    p: b.p,
    n: b.n,
    ic: b.ic || "",
    lvl: b.lvl,
    s: b.s >= 0 ? b.s : randomSeries(),
    base: b.base.map((x) => x.slice()),
    req: b.req.map((x) => x.slice()),
    price: b.price,
  };
  const blue = nMagic >= 1 && nMagic <= 2;
  const ctc = modeId() === "ctc",
    lq = luckyQ();
  it.mag = blue
    ? rollMagic(
        it,
        [b.lvl - 1, b.lvl - 2].map((v) => clamp(v, 1, 10)),
        lq,
        true,
        ctc ? Math.min(0.35, lq / 400) : 0,
      )
    : rollMagic(it, magicLevels(nMagic, b.lvl), lq);
  if (
    ctc &&
    blue &&
    it.mag.length >= 2 &&
    it.mag.qmin >= CTC_CP_Q &&
    Math.random() < Math.min(0.5, 0.15 + lq / 1e3)
  ) {
    it.cp = 1;
    it.n = "Cực phẩm · " + it.n;
  }
  const f = lineScale(S ? S.lvl : 1);
  if (f > 1)
    for (const m of it.mag)
      if (Math.abs(m.p[0]) >= 5) m.p[0] = Math.round(m.p[0] * f);
  it.r = rarityOf(it.mag.length);
  return tagItem(it);
}
function rollDrops(e) {
  DROP_BOSS = e.cls === "boss";
  try {
    return rollDrops0(e);
  } finally {
    DROP_BOSS = false;
  }
}
function rollDrops0(e) {
  const dl = dropLv(e),
    df = dropFile(dl),
    items = df.items.filter((x) => x[0] === 0 && x[1] <= 9);
  const n =
    e.cls === "boss"
      ? 2 + (Math.random() < 0.4 ? 1 : 0)
      : e.cls === "elite"
        ? Math.random() < 0.3
          ? 1
          : 0
        : Math.random() < 0.04
          ? 1
          : 0;
  const out = [];
  const dm = ((R.P && R.P.dropMul) || 1) * modeDropMul();

let cnt = Math.floor(
  n * (e.bonusDrop || 1) * dm + Math.random() * (dm > 1 ? 1 : 0),
);
// Chỉ tăng cơ hội rơi thêm đồ trong Tháp Thử Thách
if (R.tower && Math.random() < 0.25) cnt++;

  for (let i = 0; i < cnt; i++) {
    const x = wpick(items, (r) => r[3]);
    if (!x) continue;
    let [detail, part] = [x[1], x[2]];
    const f = FAC[S.fac];
    if (
      detail <= 1 &&
      f &&
      f.wcode >= 0 &&
      Math.random() < FACTION_WEAPON_SHARE
    )
      [detail, part] =
        f.wcode === 7 ? [1, irnd(0, 2)] : [0, f.wcode === 9 ? 6 : f.wcode];
    part = sexPart(detail, part);
    let it = makeItem(detail, part, itemTier(dl, df), magicCount(e.cls));
    for (let t = 0; it && !sexOk(it) && t < 6; t++)
      it = makeItem(detail, part, itemTier(dl, df), magicCount(e.cls));
    if (it && sexOk(it)) out.push(it);
  }
  return out;
}
const MONEY_TOP_MUL = 8;
const MONEY_BASE = 50,
  MONEY_TOP = Math.min(
    MONEY_BASE * MONEY_TOP_MUL,
    Math.max(
      MONEY_BASE,
      ...Object.values(J.drop).map(
        (f) => (f.main && f.main.MoneyScale) || MONEY_BASE,
      ),
    ),
  ),
  MONEY_RAMP = [100, 130];
function moneyScale(L, file) {
  if (MONEY_TOP <= MONEY_BASE) return file.main.MoneyScale || MONEY_BASE;
  return (
    MONEY_BASE *
    Math.pow(
      MONEY_TOP / MONEY_BASE,
      clamp((L - MONEY_RAMP[0]) / (MONEY_RAMP[1] - MONEY_RAMP[0]), 0, 1),
    )
  );
}
function moneyDrop(e) {
  const L = dropLv(e);
  return Math.round(
    (moneyScale(L, dropFile(L)) / 10) *
      L *
      rnd(0.6, 1.4) *
      (e.cls === "boss" ? 8 : e.cls === "elite" ? 2 : 1),
  );
}
const itemValue = (it) =>
  Math.round(((it.price || 100) / 10) * (1 + it.mag.length * 0.8));
function itemPower(it) {
  let v = it.lvl * 10;
  for (const [id, mn, mx] of it.base)
    if (id === 28 || id === 29 || id === 30) v += (mn + mx) / 2;
  for (const m of it.mag) v += 15 + Math.abs(m.p[0]) * 0.6;
  return v * enhMul(it);
}
function slotFor(it) {
  const s = DETAIL_SLOT[it.d];
  if (s === "ring" && R.P && reqOk(it)) {
    const plan = bestEquipPlan(it);
    if (plan.slot) return plan.slot;
  }
  if (s === "ring")
    return !S.eq.ring1
      ? "ring1"
      : !S.eq.ring2
        ? "ring2"
        : itemPower(S.eq.ring1) <= itemPower(S.eq.ring2)
          ? "ring1"
          : "ring2";
  return s;
}
const IDLE_INERT = [
  "indestructible_b",
  "indestructible_v",
  "durability_v",
  "durability_p",
  "not_add_pkvalue_p",
  "pk_punish_weaken",
  "pk_punish_enhance",
  "stamina_v",
  "staminamax_v",
  "staminamax_p",
  "staminareplenish_v",
  "stealstamina_p",
  "stealstaminaenhance_p",
  "fasthitrecover_v",
  "anti_hitrecover",
  "visionradius_p",
  "anti_maxres_p",
  "anti_block_rate",
  "anti_do_stun_p",
  "normal_reserve7",
  "normal_reserve8",
  "fasthitrecover_yan_v",
];
const IDLE_MAPPED = {
  knockback_p: " — bản idle: giảm sát thương nhận vào theo phần trăm",
  anti_stuntimereduce_p: " — bản idle: tăng tỉ lệ choáng",
  anti_do_hurt_p: " — bản idle: giảm kháng mọi hệ của địch",
  fatallystrikeres_p: " — bản idle: giảm sát thương Tuyệt chiêu của trùm",
  fatallystrike_p: " — bản idle: cộng vào tỉ lệ chí mạng của chiêu",
  anti_sorbdamage_yan_p: " — bản idle: tăng sát thương theo phần trăm",
  anti_sorbdamage_p: " — bản idle: tăng sát thương theo phần trăm",
  reduceskillcd1: " — bản idle: tăng tốc độ ra chiêu theo phần trăm",
  reduceskillcd2: " — bản idle: tăng tốc độ ra chiêu theo phần trăm",
  meleedamagereturnmana_p:
    " — bản idle: giảm sát thương nhận vào theo phần trăm",
  manashield_p: " — bản idle: phần trăm sát thương nhận vào trừ sang nội lực",
  dynamicmagicshield_v:
    " — bản idle: trừ thẳng số điểm này khỏi mỗi đòn nhận vào",
  returnres_p:
    " — bản idle: không có kẻ địch phản đòn nên dòng này không đổi chỉ số",
  addphysicsmagic_v: " — bản idle: cộng đúng giá trị vào chiêu nội công",
  addcoldmagic_v: " — bản idle: cộng đúng giá trị vào chiêu nội công",
  addfiremagic_v: " — bản idle: cộng đúng giá trị vào chiêu nội công",
  addlightingmagic_v: " — bản idle: cộng đúng giá trị vào chiêu nội công",
  addpoisonmagic_v: " — bản idle: cộng đúng giá trị vào chiêu nội công",
  poisontimereduce_p:
    " — bản idle: giảm sát thương Độc nhận vào bằng nửa tỉ lệ (tối đa 50%)",
  freezetimereduce_p:
    " — bản idle: giảm sát thương Băng nhận vào bằng nửa tỉ lệ (tối đa 50%)",
  stuntimereduce_p:
    " — bản idle: giảm sát thương Lôi nhận vào bằng nửa tỉ lệ (tối đa 50%)",
  damage2addmana_p: " — hồi nội lực bằng tỉ lệ này của sát thương nhận vào",
  expenhance_p: " — cộng kinh nghiệm hạ quái (tổng tối đa +50%)",
  rangedamagereturn_p: " — phản lại sát thương của quái tầm xa (tối đa 25%)",
};
Object.assign(J.attrDesc, {
  anti_allres_p: "Làm giảm kháng tất cả của đối phương: #d1+%",
  anti_sorbdamage_p: "Làm giảm triệt tiêu sát thương của đối phương: #d1+%",
  normal_reserve7: "Thuộc tính dự phòng: #d1+",
  normal_reserve8: "Thuộc tính dự phòng: #d1+",
  meleedamagereturnmana_p:
    "Khi bị công kích gần, giảm sát thương nội công của kẻ địch: #d1+%",
  expenhance_p: "Tăng kinh nghiệm nhận được: #d1+%",
});
for (const k in J.attrDesc)
  if (/sát thưởng/.test(J.attrDesc[k]))
    J.attrDesc[k] = J.attrDesc[k].replace(/sát thưởng/g, "sát thương");
const inertNote = (nm) =>
  IDLE_INERT.includes(nm)
    ? " — không tác dụng ở bản idle"
    : IDLE_MAPPED[nm] || "";
function hiddenHint(it, j) {
  if (typeof ACCRUE === "undefined" || it.s == null || it.s < 0) return "";
  const src = Object.keys(ACCRUE)
    .map(Number)
    .find((k) => ACCRUE[k] === it.s);
  if (src === undefined) return "";
  const slot =
    (typeof slotOfEquipped === "function" && slotOfEquipped(it, S.eq)) ||
    slotFor(it);
  const links = (ACTIVATED_BY[slot] || []).map((k) => SLOT_VI[k]).join(" / ");
  return `: cần ${j + 1} nguồn hệ ${SERIES[src]} (${SERIES[src]} sinh ${SERIES[it.s]}) — nhân vật${links ? " hoặc món ở " + links : ""}; đủ bộ cũng mở`;
}
function itemLines(it) {
  const L = [],
    dmin = it.base.find((b) => b[0] === 28),
    dmax = it.base.find((b) => b[0] === 29),
    k = enhMul(it);
  if (it.plv)
    L.push([
      "h on",
      `Bạch Kim +${it.plv}: thuộc tính gốc +${Math.round(it.plv * PLAT_STEP * 100)}%`,
    ]);
  if (it.enh)
    L.push([
      "h on",
      `Cường hóa +${it.enh}: thuộc tính gốc +${Math.round((k - 1) * 100)}%`,
    ]);
  if (dmin)
    L.push([
      "b",
      `Sát thương: ${Math.round(dmin[1] * k)} - ${Math.round((dmax ? dmax[1] : dmin[1]) * k)}`,
    ]);
  for (const [id, mn, mx] of it.base) {
    const nm = attrName(id);
    if (
      id === 28 ||
      id === 29 ||
      nm === "durability_v" ||
      nm === "item_purple" ||
      id === 167
    )
      continue;
    L.push([
      "b",
      attrText(nm, [Math.round(((mn + mx) / 2) * k), 0, Math.round(mx * k)]) +
        inertNote(nm),
    ]);
  }
  const act = typeof hiddenActive === "function" ? hiddenActive(it) : 0;
  const ons = magOn(it.mag, act);
  let hj = 0;
  it.mag.forEach((m, i) => {
    const hidden = isHiddenLine(m, i),
      on = ons[i],
      j = hidden ? hj++ : 0;
    L.push([
      hidden ? (on ? "h on" : "h") : "m",
      attrText(
        attrName(m.a),
        m.p.map((v) => (v === -1 ? 0 : v)),
      ) +
        (hidden && !on ? " (ẩn" + hiddenHint(it, j) + ")" : "") +
        inertNote(attrName(m.a)),
    ]);
  });
  if (it.set) {
    const ex = typeof goldEnhance === "function" ? goldEnhance(it, S.eq) : 0,
      cnt =
        typeof setCounts === "function" ? setCounts(S.eq)[it.set.grp] || 0 : 0;
    (it.ext || []).forEach((m, i) =>
      L.push([
        i < ex ? "h on" : "h",
        attrText(
          attrName(m.a),
          m.p.map((v) => (v === -1 ? 0 : v)),
        ) +
          (i < ex
            ? " (bộ)"
            : ` (mặc ${Math.min(it.set.n1 * (i + 1), it.set.n2)} món cùng bộ)`) +
          inertNote(attrName(m.a)),
      ]),
    );
    if (it.set.n2 >= 99)
      L.push([
        "r",
        `Đồ ${it.set.kind === "gold" ? "Hoàng Kim" : "Bạch Kim"} đơn lẻ: không có thưởng bộ (6 dòng cố định luôn hiệu lực)`,
      ]);
    else {
      L.push([
        "r",
        `Bộ ${it.set.kind === "gold" ? "Hoàng Kim" : "Bạch Kim"}: đang mặc ${cnt} món · đủ ${it.set.n2} món mở hết dòng ẩn mọi trang bị`,
      ]);
      for (const r of setMembers(it).filter(
        (r) => /^\[/.test(r.n) === /^\[/.test(it.n),
      )) {
        const sig = itSig(r);
        L.push([
          "r",
          `  ${Object.values(S.eq).some((e) => e && e.set && (e.refId ? e.refId === r.refId : itSig(e) === sig)) ? "✔" : "·"} ${r.n}`,
        ]);
      }
    }
  }
  const REQ = {
    36: "Cấp",
    32: "Sức mạnh",
    33: "Thân pháp",
    34: "Sinh khí",
    35: "Nội công",
    37: "Hệ",
    38: "Giới tính",
    39: "Môn phái",
  };
  for (const [id, v] of it.req)
    if (REQ[id] && (v > 0 || id === 39))
      L.push([
        "r",
        `Yêu cầu ${REQ[id]}: ${id === 37 ? SERIES[v] : id === 39 ? (J.factions[v] || {}).n || v : v}`,
      ]);
  for (const s of goiY(it)) L.push(["r", s]);
  return L;
}
function goiY(it) {
  const out = [];
  if (!it) return out;
  const n = (it.mag || []).length;
  const canEnchase =
    !it.set && it.d >= 0 && it.d <= 9 && (n === 0 ? it.r === 0 : !!it.vio);
  if (
    MC().lab &&
    MC().vio &&
    canEnchase &&
    typeof enchaseCheck === "function" &&
    typeof mats === "function" &&
    typeof oreParse === "function" &&
    typeof VIO_SLOTS === "number"
  ) {
    if (n >= VIO_SLOTS) out.push("Khảm: đã đủ 6 dòng — không khảm thêm được");
    else {
      const hts = Object.keys(mats().ht)
        .map(Number)
        .sort((a, b) => a - b);
      const ores = Object.keys(mats().ore).filter(
        (k) => oreParse(k).place === n,
      );
      if (hts.length && ores.length) {
        const row = enchaseCheck(it, hts[0], ores[0]);
        out.push(
          typeof row === "string"
            ? `Khảm dòng ${n + 1}/6: ${row}`
            : `Khảm dòng ${n + 1}/6: Huyền Tinh cấp ${hts[0]} + ${oreLabel(ores[0])} · thất bại 5% mất đá`,
        );
      } else
        out.push(
          `Khảm dòng ${n + 1}/6: cần Huyền Tinh cấp bất kỳ + khoáng thạch dòng ${n + 1}`,
        );
    }
  }
  if (MC().lab && typeof canFuse === "function" && canFuse(it)) {
    const dv = (typeof RCP_R !== "undefined" &&
      RCP_R.violet_fuse.level_div) || [10, 5];
    const s = (it.lvl || 1) * 3;
    out.push(
      `Hợp Huyền Tinh: món này + 2 nhẫn/dây chuyền/ngọc bội → Huyền Tinh cấp ~${Math.max(1, Math.floor(s / dv[0]))}–${Math.max(1, Math.floor(s / dv[1]))} · phí ${fmt(typeof fuseCost === "function" ? fuseCost() : 1e3)} lượng`,
    );
  }
  if (
    platinaOn() &&
    it.set &&
    it.set.kind === "gold" &&
    it.refId &&
    typeof platinaPairId === "function"
  ) {
    const pair = platinaPairId(it);
    if (!pair)
      out.push("Chế Bạch Kim: dữ liệu gốc chưa xác định cặp cho món này");
    else if (typeof platBaseRows === "function" && !platBaseRows(pair).length)
      out.push("Chế Bạch Kim: dữ liệu game không có mẫu Bạch Kim tương ứng");
    else if (typeof canPlatBase === "function" && canPlatBase(it))
      out.push(
        "Chế Bạch Kim: cần 2 món Hoàng Kim GIỐNG NHAU + Thủy Tinh Trắng",
      );
  }
  if (MC().rforge && typeof RF_MUC !== "undefined" && !it.set)
    out.push(
      `Rèn ngẫu nhiên (Lò Huyền Tinh): tốn vàng, KHÔNG dùng món này — ${RF_MUC.map((m) => m.n + " " + Math.round(m.ty * 100) + "%").join(" / ")} ra đồ mới, hỏng mất vàng`,
    );
  return out;
}
const GROUND_MAX = 40,
  PICK_R = 26;
const LOOT_ATTR_GROUPS = [
  [
    "Sinh lực",
    ["lifemax_v", "lifemax_p", "lifereplenish_v", "lifereplenish_p"],
  ],
  ["Nội lực", ["manamax_v", "manamax_p", "manareplenish_v"]],
  [
    "Sát thương",
    [
      "skill_enhance",
      "enhancehit_rate",
      "addphysicsdamage_v",
      "addphysicsdamage_p",
      "addfiredamage_v",
      "addcolddamage_v",
      "addlightingdamage_v",
      "addpoisondamage_v",
      "weapondamagemin_v",
      "weapondamagemax_v",
      "weapondamageenhance_p",
    ],
  ],
  [
    "Kháng",
    [
      "sorbdamage_p",
      "block_rate",
      "physicsres_p",
      "poisonres_p",
      "coldres_p",
      "fireres_p",
      "lightingres_p",
      "allres_p",
    ],
  ],
  ["Chỉ số", ["strength_v", "dexterity_v", "vitality_v", "energy_v"]],
  [
    "Kỹ năng",
    [
      "allskill_v",
      "addphysicsmagic_v",
      "addcoldmagic_v",
      "addfiremagic_v",
      "addlightingmagic_v",
      "addpoisonmagic_v",
    ],
  ],
  ["Tốc độ", ["attackspeed_v", "castspeed_v", "fastwalkrun_p"]],
  [
    "Hút máu / nội",
    ["steallife_p", "stealmana_p", "steallifeenhance_p", "stealmanaenhance_p"],
  ],
  [
    "Chính xác / né",
    [
      "attackrating_v",
      "attackratingenhance_v",
      "attackratingenhance_p",
      "adddefense_v",
      "armordefense_v",
    ],
  ],
  [
    "Ngũ hành",
    [
      "metalskill_v",
      "woodskill_v",
      "waterskill_v",
      "fireskill_v",
      "earthskill_v",
    ],
  ],
];
function lootFilter() {
  if (!S.lootF || !Array.isArray(S.lootF.rules))
    S.lootF = normalizeLootFilter(Object.assign({ minRar: 1 }, S.lootF || {}));
  return S.lootF;
}
function lootMatch(it) {
  const f = lootFilter();
  if (it.r < f.minRar || it.lvl < f.minLvl) return false;
  if (f.kw && !kwHit(it.n, f.kw)) return false;
  if (f.series.length && !f.series.includes(it.s)) return false;
  if (
    f.wearableOnly &&
    (!reqOk(it) ||
      (DETAIL_SLOT[it.d] === "weapon" &&
        FAC[S.fac].wcode >= 0 &&
        weaponCode({ weapon: it }) !== FAC[S.fac].wcode))
  )
    return false;
  if (f.groups.length || f.rules.length) {
    const values = itemAttributeValues(it, f.activeOnly),
      matches = [];
    for (const g of f.groups)
      matches.push(
        (LOOT_ATTR_GROUPS[g] || ["", []])[1].some(
          (n) => values[canonAttr(n)] > 0,
        ),
      );
    for (const rule of f.rules)
      matches.push((values[rule.attr] || 0) >= rule.min);
    if (
      !(f.ruleMode === "all" ? matches.every(Boolean) : matches.some(Boolean))
    )
      return false;
  }
  return true;
}
function dropToGround(it, at) {
  const a = rnd(0, Math.PI * 2),
    d = rnd(10, 26);
  const [x, y] = inWorld(at.x + Math.cos(a) * d, at.y + Math.sin(a) * d);
  R.ground.push({ it: it, x: x, y: y, age: 0 });
  if (R.ground.length > GROUND_MAX) {
    let i = R.ground.findIndex(
      (d) =>
        !isKept(d.it) &&
        bestEquipPlan(d.it).gain <= 0.01 &&
        !preferredLoot(d.it),
    );
    if (i < 0) return;
    const old = R.ground.splice(i, 1)[0];
    S.gold += itemValue(old.it);
  }
  if (!R.quiet)
    uiSfx(
      it.d <= 1
        ? "dropWeapon"
        : it.d === 2 || it.d === 7
          ? "dropCloth"
          : "dropOther",
    );
  if (it.r >= 2 && !R.quiet)
    log(
      `Rơi xuống đất: <span style="color:${RAR_COL[it.r]}">${esc(it.n)}</span>`,
    );
}
function makeRoom(it, force) {
  const worst = roomCandidate(it, force);
  if (!worst) return false;
  S.gold += itemValue(worst);
  S.inv.splice(S.inv.indexOf(worst), 1);
  invDirty = true;
  return true;
}
function pickUp(drop, quiet) {
  const i = R.ground.indexOf(drop);
  if (i < 0) return false;
  if (S.inv.length >= INV_MAX && !makeRoom(drop.it)) {
    if (!quiet) toast("Hành trang đầy");
    return false;
  }
  R.ground.splice(i, 1);
  addItem(drop.it, quiet, true, R.pickTarget === drop);
  questTick("picked");
  if (R.pickTarget === drop) R.pickTarget = null;
  return true;
}
function updateGround(dt) {
  for (const d of R.ground) d.age += dt;
  let target =
    R.pickTarget && R.ground.includes(R.pickTarget) ? R.pickTarget : null;
  if (
    !target &&
    lootFilter().auto &&
    !(typeof manual === "function" && manual()) &&
    !R.enemies.some((e) => !e.dead)
  ) {
    let best = null,
      bd = 1e9;
    const full = S.inv.length >= INV_MAX;
    let bestUpgrade = false;
    for (const d of R.ground) {
      if (d.age < 0.4 || !lootWanted(d.it) || (full && !roomCandidate(d.it)))
        continue;
      const k = Math.hypot(d.x - H.x, d.y - H.y),
        up =
          lootFilter().pickMode === "upgrade" &&
          bestEquipPlan(d.it).gain > 0.01;
      if ((up && !bestUpgrade) || (up === bestUpgrade && k < bd)) {
        bd = k;
        best = d;
        bestUpgrade = up;
      }
    }
    target = best;
  }
  if (!target) return false;
  const dist = Math.hypot(target.x - H.x, target.y - H.y);
  if (dist <= PICK_R) {
    pickUp(target, true);
    return true;
  }
  obsSteer(H, target.x, target.y, 170 * (R.P ? R.P.speed : 1) * dt);
  H.face = target.x >= H.x ? 1 : -1;
  return true;
}
function groundAt(x, y) {
  let best = null,
    bd = 30;
  for (const d of R.ground) {
    const k = Math.hypot(d.x - x, d.y - (y + 6));
    if (k < bd) {
      bd = k;
      best = d;
    }
  }
  return best;
}
function saveGround() {
  S.ground = R.ground.map((d) => ({ it: d.it, wx: d.x, wy: d.y }));
}
function restoreGround() {
  R.ground = (S.ground || [])
    .filter((g) => g && g.it)
    .map((g) => {
      const [x, y] = inWorld(g.wx ?? WORLD.w / 2, g.wy ?? WORLD.h / 2);
      return { it: g.it, x: x, y: y, age: 1 };
    });
}
