"use strict";
const MODE_IDS = ["ctc"];
const MODES = {
  ctc: {
    id: "ctc",
    n: "Công Thành Chiến",
    short: "CTC",
    tag: "Cày chay",
    rank: 0,
    sfx: "_ctc",
    col: "#6aa8ff",
    desc: "Cày chay: chỉ đồ Xanh và Vàng, không Tím, không Hoàng Kim. Không đường tắt về đồ hay tốc độ, độ khó Thường cố định; có thưởng EXP từ hoạt động, nhiệm vụ và buff tu luyện. May mắn ×5 cho chất lượng đồ Xanh (không tăng số lượng đồ rơi): hiếm khi rơi đồ Xanh «Cực phẩm» với mọi dòng gần tối đa.",
    forWho: "Thích cày đều, thong thả, lên cấp bằng chính tay mình.",
    rarMax: 2,
    hk: false,
    platina: false,
    vio: false,
    lab: false,
    rforge: false,
    admin: false,
    tx: 0,
    speeds: [1],
    defSpeed: 1,
    diff: 1,
    expMul: 1,
    dropMul: 1,
    chalHard: false,
    stars: 2,
    pace: "EXP ×1 · thủ công +20%",
  },
  phlt: {
    id: "phlt",
    n: "Phong Hoả Liên Thành",
    short: "PHLT",
    tag: "Săn Hoàng Kim",
    rank: 1,
    sfx: "_phlt",
    col: "#ff8a3a",
    desc: "Trần đồ chỉ tới Tím và Hoàng Kim, không có Bạch Kim. Độ khó Khó cố định, săn bộ Hoàng Kim, khảm Tím, rèn ngẫu nhiên.",
    forWho: "Thích săn đồ, tối ưu build và chịu được khó.",
    rarMax: 4,
    hk: true,
    platina: false,
    vio: true,
    lab: true,
    rforge: true,
    admin: false,
    tx: 3,
    speeds: [1],
    defSpeed: 1,
    diff: 2,
    expMul: 0.8,
    dropMul: 1,
    chalHard: true,
    stars: 4,
    pace: "EXP/quái ×1.2 · quái máu ×3",
  },
  g2: {
    id: "g2",
    n: "2.0",
    short: "2.0",
    tag: "Giải trí",
    rank: 2,
    sfx: "",
    col: "#c77bff",
    desc: "Giải trí cao: không trần đồ, có Bạch Kim, đồ rơi nhiều, đột biến mỗi ngày, kỳ ngộ, vòng quay, tốc độ x2.5 mặc định.",
    forWho: "Thích thư giãn, sướng tay, xem đồ nổ liên tục.",
    rarMax: 5,
    hk: true,
    platina: true,
    vio: true,
    lab: true,
    rforge: true,
    admin: true,
    tx: 20,
    speeds: [1, 1.5, 2.5],
    defSpeed: 2.5,
    diff: null,
    expMul: 2,
    dropMul: 1.5,
    chalHard: true,
    stars: 1,
    pace: "EXP nhanh ×2",
  },
};
const isMode = (x) => x === "ctc";
let MODE_CTX = null;
const _curS = () => {
  try {
    return S;
  } catch (e) {
    return null;
  }
};
const modeId = () =>
  MODE_CTX ||
  (() => {
    const s = _curS();
    return s && isMode(s.mode) ? s.mode : "ctc";
  })();
const MC = () => MODES[modeId()];
const modeOf = (id) => (isMode(id) ? MODES[id] : MODES.ctc);
const modeSfx = () => MC().sfx;
const modeAllows = (k) => !!MC()[k];
const platinaOn = () => !!MC().platina;
const modeBlockMsg = (what) => `${what} không có ở chế độ ${MC().n}`;
const modeBadge = (id, small) => {
  const m = modeOf(id);
  return `<span class="mbadge${small ? " sm" : ""}" style="--c:${m.col}">${m.n}</span>`;
};
const clanKey = () => "jxidle_clan" + modeSfx();
const guildKey = () => "jxidle_guild" + modeSfx();
const collKey = () => "jxidle_collections" + modeSfx();
const stashKey = () => "jxidle_stash" + modeSfx();
const stateMode = (o) =>
  o && typeof o === "object" && isMode(o.mode)
    ? o.mode
    : o && o.fac
      ? "ctc"
      : null;
const sealKey = (i) => slotKey(i) + "_m";
function sealRead(i) {
  try {
    const o = JSON.parse(localStorage.getItem(sealKey(i)) || "null");
    if (o && isMode(o.m) && o.h === sigOf("seal:" + i + ":" + o.m)) return o.m;
  } catch (e) {}
  return null;
}
function sealWrite(i, mode) {
  if (!isMode(mode)) return;
  try {
    localStorage.setItem(
      sealKey(i),
      JSON.stringify({ m: mode, h: sigOf("seal:" + i + ":" + mode) }),
    );
  } catch (e) {}
}
function modeReconcile(i, m) {
  const s = sealRead(i);
  if (!m || !s || s === m) return m || s;
  window.__modeTamper = true;
  return MODES[s].rank < MODES[m].rank ? s : m;
}
function modeAfterLoad() {
  if (!S || !S.fac) return;
  const r = modeReconcile(SLOT, S.mode);
  if (r && r !== S.mode) {
    S.mode = r;
    modeSanitize(S);
  }
  sealWrite(SLOT, S.mode);
  collectionsCache = null;
}
function modeItemOk(it, mode) {
  const c = isMode(mode) ? MODES[mode] : null;
  if (!c || !it || typeof it !== "object") return true;
  if (it.mo && isMode(it.mo) && it.mo !== mode && mode !== "g2") return false;
  if ((it.r | 0) > c.rarMax) return false;
  if (!c.vio && it.vio) return false;
  if (!c.hk && it.set) return false;
  if (!c.platina && (it.plv || (it.set && it.set.kind === "platina")))
    return false;
  return true;
}
function tagItem(it) {
  if (!it || typeof it !== "object" || it.mo) return it;
  const s = _curS();
  if (!s || !s.fac || !isMode(s.mode)) return it;
  it.mo = s.mode;
  const ml = s.ml || (s.ml = { sec: 0, hk: 0, vio: 0 });
  if (it.set) ml.hk = (ml.hk | 0) + 1;
  return it;
}
function modeClock(sec) {
  const s = _curS();
  if (s && s.fac && sec > 0) {
    const ml = s.ml || (s.ml = { sec: 0, hk: 0, vio: 0 });
    ml.sec = (+ml.sec || 0) + sec;
  }
}
function modeAudit(s) {
  const c = isMode(s.mode) ? MODES[s.mode] : null;
  if (!c) return 0;
  const ml = s.ml,
    over =
      (!c.hk && ml.hk > 0) ||
      (s.mode === "phlt" && ml.hk > 8 + (ml.sec / 3600) * 3);
  return over ? 1 : 0;
}
function modeSanitize(s) {
  const c = s && s.fac && isMode(s.mode) ? MODES[s.mode] : null;
  if (!c) return 0;
  s.ml = Object.assign(
    { sec: 0, hk: 0, vio: 0 },
    s.ml && typeof s.ml === "object" ? safeKeys(s.ml) : {},
  );
  for (const k of ["sec", "hk", "vio"])
    s.ml[k] = Number.isFinite(+s.ml[k]) ? Math.max(0, +s.ml[k]) : 0;
  if (!c.speeds.includes(+s.speed))
    s.speed = c.defSpeed === 2.5 ? 1 : c.defSpeed;
  if (c.diff != null) s.diff = c.diff;
  if (!c.chalHard && s.chal === "hard") s.chal = "";
  if (!c.admin) s.adminDay = "";
  const val = (it) => {
    try {
      return typeof itemValue === "function" ? itemValue(it) : 0;
    } catch (e) {
      return 0;
    }
  };
  let n = 0;
  for (const k of Object.keys(s.eq || {})) {
    const it = s.eq[k];
    if (it && !modeItemOk(it, s.mode)) {
      s.gold += val(it);
      delete s.eq[k];
      n++;
    }
  }
  s.inv = (s.inv || []).filter((it) => {
    if (modeItemOk(it, s.mode)) return true;
    s.gold += val(it);
    n++;
    return false;
  });
  if (Array.isArray(s.ground))
    s.ground = s.ground.filter((g) => {
      if (!g || !g.it || modeItemOk(g.it, s.mode)) return true;
      s.gold += val(g.it);
      n++;
      return false;
    });
  if (!c.lab) s.mats = { ht: {}, ore: {}, shard: {}, misc: {} };
  if (n) {
    s.modeStrip = (s.modeStrip | 0) + n;
    window.__modeStrip = (window.__modeStrip | 0) + n;
  }
  s.mflag = modeAudit(s);
  return n;
}
const modeSpeeds = () => MC().speeds;
const modeSpeedOk = (v) => MC().speeds.includes(+v);
const modeDiffLocked = () => MC().diff != null;
const MUTATORS = [
  { k: "gold", n: "Mưa Vàng", d: "Ngân lượng rơi ×3", gold: 3 },
  { k: "drop", n: "Rừng Đồ", d: "Đồ rơi ×2", drop: 2 },
  { k: "lucky", n: "Gió Lộc", d: "+25 may mắn", lucky: 25 },
  {
    k: "boss",
    n: "Trùm Đại Náo",
    d: "Trùm Hoàng Kim xuất hiện nhanh gấp đôi",
    gb: 2,
  },
  {
    k: "rage",
    n: "Quái Cuồng",
    d: "Quái mạnh hơn 25% nhưng kinh nghiệm ×2",
    xp: 2,
    hpMul: 1.25,
    dmgMul: 1.25,
  },
  {
    k: "calm",
    n: "Ngày Thái Bình",
    d: "Quái yếu hơn 20%, ngân lượng ×1.5",
    hpMul: 0.8,
    dmgMul: 0.8,
    gold: 1.5,
  },
];
function mutatorOfDay(day) {
  let h = 7;
  for (const ch of String(day)) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return MUTATORS[h % MUTATORS.length];
}
const mutator = () => (modeId() === "g2" ? mutatorOfDay(localISODay()) : null);
const mutVal = (f, d = 1) => {
  const m = mutator();
  return m && m[f] != null ? m[f] : d;
};
var ADMV = {
  xp: 15,
  gold: 3,
  drop: 1,
  hp: 1,
  dmg: 0.5,
  heroDmg: 5,
  spawn: 2.5,
  lucky: 0,
  speed: 3,
  god: 0,
  infMana: 0,
  sandbox: 0,
};
const modeXpMul = () => MC().expMul * mutVal("xp") * ADMV.xp;
const modeGoldMul = () => mutVal("gold") * ADMV.gold;
const modeDropMul = () => MC().dropMul * mutVal("drop") * ADMV.drop;
const slotModeOf = (i) => {
  const inf = slotInfo(i);
  return inf ? inf.mode : null;
};
const sameModeSlot = (i) => slotModeOf(i) === modeId();
